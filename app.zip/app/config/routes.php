<?php
declare(strict_types=1);

use Cake\Routing\Route\DashedRoute;
use Cake\Routing\RouteBuilder;

return static function (RouteBuilder $routes): void {
    $routes->setRouteClass(DashedRoute::class);

    $routes->scope('/', function (RouteBuilder $builder): void {
        $builder->connect('/', ['controller' => 'Recepti', 'action' => 'index']);
        $builder->connect('/prijava', ['controller' => 'Uporabniki', 'action' => 'prijava']);
        $builder->connect('/registracija', ['controller' => 'Uporabniki', 'action' => 'registracija']);
        $builder->connect('/odjava', ['controller' => 'Uporabniki', 'action' => 'odjava']);
        $builder->connect('/profil', ['controller' => 'Uporabniki', 'action' => 'profil']);
        $builder->connect('/recepti/dodaj', ['controller' => 'Recepti', 'action' => 'dodaj']);
        $builder->connect('/recepti/uredi/*', ['controller' => 'Recepti', 'action' => 'uredi']);
        $builder->connect('/recepti/izbrisi/*', ['controller' => 'Recepti', 'action' => 'izbrisi']);
        $builder->connect('/recepti/{id}', ['controller' => 'Recepti', 'action' => 'view'], ['id' => '\d+', 'pass' => ['id']]);
        $builder->connect('/recepti', ['controller' => 'Recepti', 'action' => 'index']);
        $builder->connect('/komentarji/dodaj/*', ['controller' => 'Komentarji', 'action' => 'dodaj']);
        $builder->connect('/komentarji/izbrisi/*', ['controller' => 'Komentarji', 'action' => 'izbrisi']);
        $builder->connect('/admin', ['controller' => 'Admin', 'action' => 'index']);
        $builder->connect('/admin/izbrisi-uporabnika/*', ['controller' => 'Admin', 'action' => 'izbrisiUporabnika']);
        $builder->connect('/admin/izbrisi-recept/*', ['controller' => 'Admin', 'action' => 'izbrisiRecept']);
        $builder->connect('/admin/izbrisi-komentar/*', ['controller' => 'Admin', 'action' => 'izbrisiKomentar']);
        $builder->fallbacks(DashedRoute::class);
    });
};