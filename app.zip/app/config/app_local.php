<?php
return [
    'Security' => [
        'salt' => 'neka-dolga-nakljucna-beseda-vsaj-32-znakov-1234567890',
    ],
    'Datasources' => [
        'default' => [
            'host' => 'kuharski_db',
            'username' => 'programski_dostop',
            'password' => 'geslo123',
            'database' => 'kuharji',
            'encoding' => 'utf8mb4',
            'timezone' => 'Europe/Ljubljana',
        ],
        'test' => [
            'host' => 'kuharski_db',
            'username' => 'programski_dostop',
            'password' => 'geslo123',
            'database' => 'kuharji_test',
            'encoding' => 'utf8mb4',
            'timezone' => 'Europe/Ljubljana',
        ],
    ],
];